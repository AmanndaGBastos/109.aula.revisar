function startClassification()
{
 
}

function modelReady(){
  
}

function gotResults(error, results) {
  
}
